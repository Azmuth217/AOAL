@echo off
cd /d "%~dp0"
python job_application_tracker.py
if errorlevel 1 (
    echo.
    echo The program could not start. Confirm Python is installed and available as "python".
    pause
)
