#!/bin/sh
cd "$(dirname "$0")"
python3 job_application_tracker.py
