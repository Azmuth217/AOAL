# AOAL Initial Setup & Getting Started

AOAL (Archivist's Organized Application Log, pronounced "Owl") is a local desktop job-application tracker built with Python, Tkinter, and SQLite. AOAL stores its working data beside the program so it can be backed up, moved, or shared without requiring an online account.

## 1. What is included in a new AOAL copy

A clean AOAL package includes:

- `job_application_tracker.py` - the application
- `run_job_tracker.sh` - macOS/Linux launcher
- `run_job_tracker.bat` - Windows launcher
- `job_tracker_data/job_applications.db` - a blank SQLite database with AOAL's tables already created
- `job_tracker_data/attachments/` - storage for copies of documents attached to applications
- `job_tracker_data/resumes.txt` - your personal list of resume names/versions used by the Resume Used dropdown

The blank database contains no job applications, notes, recruiters, questions, or attachments.

## 2. Starting AOAL

### macOS / Linux

Open a terminal in the AOAL folder and run:

```bash
chmod +x run_job_tracker.sh
./run_job_tracker.sh
```

You can also run:

```bash
python3 job_application_tracker.py
```

### Windows

Double-click `run_job_tracker.bat`, or open Command Prompt/PowerShell in the AOAL folder and run:

```bat
python job_application_tracker.py
```

AOAL requires Python 3 with Tkinter support.

## 3. Add your resume choices before your first application

AOAL tracks which resume version you used for each application. The Resume Used dropdown is personal to each AOAL installation.

1. Launch AOAL.
2. Click **Manage Resumes** on the main toolbar.
3. Enter one resume name or version per line.
4. Click **Save**.
5. Open a new application and select the appropriate resume from the **Documents** tab.

Example labels:

```text
Resume 1 Customer Service
Resume 2 Custodial Engineer
Resume 3 General Contractor
```

Use names that help you identify the exact version you submitted. You can change the list later through **Manage Resumes**.

### Adding the actual resume file to an application

The Resume Used dropdown records the resume name/version. If you also want AOAL to preserve a copy of the actual file used for a particular application:

1. Open the application.
2. Select the **Documents** tab.
3. Under **Custom document name**, enter a useful name such as `Resume 2 Custodial Engineer`.
4. Click **Browse** and choose the resume file.
5. Click **Add Document**.

AOAL copies the document into that application's folder under `job_tracker_data/attachments/`.

## 4. Add your first job application

1. Click **Add Application**.
2. Enter at least the Company and Job Title.
3. Complete the Job tab with the posting URL, pay if disclosed, location, work arrangement, employment type, and requisition ID when available.
4. Use the Recruiter & Timeline tab for application dates, recruiter contact information, and interview information.
5. Use Follow-Ups & Questions for the next follow-up date and questions you still need the employer or recruiter to answer.
6. Use Documents to record the resume/application materials used and attach important files.
7. Paste the job description and add confirmed communication/activity notes in Description & Notes.
8. Click **Save**.

For active applications, AOAL can automatically set a follow-up date seven days after the Applied Date when no custom date is entered.

## 5. Right-click editing

AOAL 1.9 adds a standard right-click menu to text-entry areas. Right-click inside an editable field to use:

- Cut
- Copy
- Paste
- Delete
- Select All

Keyboard shortcuts continue to work as before.

## 6. Back up your data

Your important data lives in the entire `job_tracker_data` folder, not only the database file.

Use **Back Up Data** in AOAL to create a ZIP containing the database and attachments. You can also close AOAL and manually copy the entire `job_tracker_data` folder.

Keep backups before upgrading AOAL or moving it to another computer.

## 7. Moving an existing AOAL installation to a newer version

1. Close AOAL.
2. Back up the entire existing `job_tracker_data` folder.
3. Extract the new AOAL version.
4. Replace the new blank `job_tracker_data` folder with your existing one.
5. Launch AOAL and verify your applications and attachments.

AOAL 1.9 preserves the existing v1.8 database schema. Existing resume names found in an upgraded database can be carried into the new `resumes.txt` list automatically when the list is empty.

## 8. Before sharing AOAL with someone else

For a clean new-user copy, verify that:

- `job_applications.db` contains no personal application records.
- `resumes.txt` contains no personal resume names unless intentionally included as examples.
- `attachments/` contains no personal documents.
- No exported CSV files, backups, resumes, cover letters, or other personal files are included in the shared folder.

The clean distribution included with AOAL 1.9 is designed to start with an empty database and empty resume list.
