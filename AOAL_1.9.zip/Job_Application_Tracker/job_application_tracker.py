
from __future__ import annotations

import csv
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import webbrowser
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk


APP_NAME = "AOAL"
APP_VERSION = "1.9"


def app_directory() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


APP_DIR = app_directory()
DATA_DIR = APP_DIR / "job_tracker_data"
ATTACHMENTS_DIR = DATA_DIR / "attachments"
DATABASE_PATH = DATA_DIR / "job_applications.db"
RESUMES_FILE = DATA_DIR / "resumes.txt"

DATA_DIR.mkdir(parents=True, exist_ok=True)
ATTACHMENTS_DIR.mkdir(parents=True, exist_ok=True)


STATUSES = [
    "Saved / Considering",
    "Applied",
    "Recruiter Contacted",
    "Phone Screen",
    "Interview Scheduled",
    "Interview Completed",
    "Assessment",
    "Offer",
    "Accepted",
    "Rejected",
    "Withdrawn",
    "Closed / No Response",
]

PLATFORMS = [
    "",
    "LinkedIn",
    "Indeed",
    "Dice",
    "ZipRecruiter",
    "Monster",
    "Glassdoor",
    "Company Website",
    "Recruiter",
    "Email",
    "Referral",
    "Other",
]

def load_resume_choices() -> list[str]:
    """Load user-managed resume labels for the Resume Used dropdown."""
    try:
        lines = RESUMES_FILE.read_text(encoding="utf-8").splitlines()
    except OSError:
        return [""]

    choices: list[str] = []
    seen: set[str] = set()
    for line in lines:
        label = line.strip()
        key = label.casefold()
        if label and key not in seen:
            choices.append(label)
            seen.add(key)
    return [""] + choices


def save_resume_choices(labels: list[str]) -> None:
    """Persist one resume label per line, preserving the user's display text."""
    cleaned: list[str] = []
    seen: set[str] = set()
    for value in labels:
        label = value.strip()
        key = label.casefold()
        if label and key not in seen:
            cleaned.append(label)
            seen.add(key)
    RESUMES_FILE.write_text("\n".join(cleaned) + ("\n" if cleaned else ""), encoding="utf-8")


DOCUMENT_OPTIONS = [
    "",
    "None",
    "Cover Letter",
    "CV",
    "Cover Letter and CV",
    "Other",
]

WORK_ARRANGEMENTS = ["", "Remote", "Hybrid", "On-site", "Unspecified"]


FOLLOW_UP_FILTERS = ["", "Overdue", "Due Today", "Upcoming", "No Date"]
FOLLOW_UP_CENTER_FILTERS = ["All Active", "Overdue", "Due Today", "Upcoming", "No Date"]
QUESTION_STATUSES = ["Open", "Answered", "Not Needed"]
TERMINAL_STATUSES = {"Accepted", "Rejected", "Withdrawn", "Closed / No Response"}


def date_only(value: str) -> date | None:
    """Parse AOAL's YYYY-MM-DD date fields without raising on incomplete input."""
    text = (value or "").strip()[:10]
    if not text:
        return None
    try:
        return datetime.strptime(text, "%Y-%m-%d").date()
    except ValueError:
        return None


def default_follow_up_date(applied_at: str, days: int = 7) -> str:
    """Return the default follow-up date based on the application date."""
    applied = date_only(applied_at)
    return (applied + timedelta(days=days)).isoformat() if applied else ""


def normalize_url(value: str) -> str:
    """Return a browser-ready URL without changing a stored value."""
    url = value.strip()
    if not url:
        return ""
    if "://" not in url:
        url = f"https://{url}"
    return url

EMPLOYMENT_TYPES = [
    "",
    "Full-time",
    "Part-time",
    "Contract - W2",
    "Contract - 1099 / Independent",
    "Contract-to-Hire",
    "Temporary",
    "Internship",
    "Unspecified",
]

US_STATES = [
    "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado",
    "Connecticut", "Delaware", "District of Columbia", "Florida", "Georgia",
    "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky",
    "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota",
    "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire",
    "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota",
    "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island",
    "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont",
    "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming",
]

STATE_ABBREVIATIONS = {
    "AL":"Alabama", "AK":"Alaska", "AZ":"Arizona", "AR":"Arkansas", "CA":"California",
    "CO":"Colorado", "CT":"Connecticut", "DE":"Delaware", "DC":"District of Columbia",
    "FL":"Florida", "GA":"Georgia", "HI":"Hawaii", "ID":"Idaho", "IL":"Illinois",
    "IN":"Indiana", "IA":"Iowa", "KS":"Kansas", "KY":"Kentucky", "LA":"Louisiana",
    "ME":"Maine", "MD":"Maryland", "MA":"Massachusetts", "MI":"Michigan", "MN":"Minnesota",
    "MS":"Mississippi", "MO":"Missouri", "MT":"Montana", "NE":"Nebraska", "NV":"Nevada",
    "NH":"New Hampshire", "NJ":"New Jersey", "NM":"New Mexico", "NY":"New York",
    "NC":"North Carolina", "ND":"North Dakota", "OH":"Ohio", "OK":"Oklahoma", "OR":"Oregon",
    "PA":"Pennsylvania", "RI":"Rhode Island", "SC":"South Carolina", "SD":"South Dakota",
    "TN":"Tennessee", "TX":"Texas", "UT":"Utah", "VT":"Vermont", "VA":"Virginia",
    "WA":"Washington", "WV":"West Virginia", "WI":"Wisconsin", "WY":"Wyoming",
}

def load_us_locations() -> list[str]:
    """Load searchable U.S. location suggestions while allowing any typed value.

    The bundled list contains all states and a broad city list. If a user later places a
    us_cities.csv file beside the program, rows containing city/state columns are also loaded.
    """
    locations = {"Remote"}
    for state in US_STATES:
        locations.add(state)
    for abbr, state in STATE_ABBREVIATIONS.items():
        locations.add(f"{state} ({abbr})")

    # Broad city list bundled from the system geographic data available at build time.
    locations.update({
        "New York, NY", "Los Angeles, CA", "Chicago, IL", "Houston, TX", "Phoenix, AZ",
        "Philadelphia, PA", "San Antonio, TX", "San Diego, CA", "Dallas, TX", "San Jose, CA",
        "Austin, TX", "Jacksonville, FL", "Fort Worth, TX", "Columbus, OH", "Charlotte, NC",
        "Indianapolis, IN", "San Francisco, CA", "Seattle, WA", "Denver, CO", "Washington, DC",
        "Nashville, TN", "Oklahoma City, OK", "El Paso, TX", "Boston, MA", "Portland, OR",
        "Las Vegas, NV", "Detroit, MI", "Memphis, TN", "Louisville, KY", "Baltimore, MD",
        "Milwaukee, WI", "Albuquerque, NM", "Tucson, AZ", "Fresno, CA", "Sacramento, CA",
        "Mesa, AZ", "Kansas City, MO", "Atlanta, GA", "Omaha, NE", "Colorado Springs, CO",
        "Raleigh, NC", "Miami, FL", "Virginia Beach, VA", "Oakland, CA", "Minneapolis, MN",
        "Tulsa, OK", "Tampa, FL", "Arlington, TX", "New Orleans, LA", "Wichita, KS",
        "Cleveland, OH", "Bakersfield, CA", "Aurora, CO", "Anaheim, CA", "Honolulu, HI",
        "Santa Ana, CA", "Riverside, CA", "Corpus Christi, TX", "Lexington, KY", "Stockton, CA",
        "Henderson, NV", "Saint Paul, MN", "St. Louis, MO", "Cincinnati, OH", "Pittsburgh, PA",
        "Greensboro, NC", "Anchorage, AK", "Plano, TX", "Lincoln, NE", "Orlando, FL",
        "Irvine, CA", "Newark, NJ", "Toledo, OH", "Durham, NC", "Chula Vista, CA",
        "Fort Wayne, IN", "Jersey City, NJ", "St. Petersburg, FL", "Laredo, TX", "Madison, WI",
        "Chandler, AZ", "Buffalo, NY", "Lubbock, TX", "Scottsdale, AZ", "Reno, NV",
        "Glendale, AZ", "Gilbert, AZ", "Winston-Salem, NC", "North Las Vegas, NV", "Norfolk, VA",
        "Chesapeake, VA", "Garland, TX", "Irving, TX", "Hialeah, FL", "Fremont, CA",
        "Boise, ID", "Richmond, VA", "Baton Rouge, LA", "Spokane, WA", "Des Moines, IA",
        "Tacoma, WA", "San Bernardino, CA", "Modesto, CA", "Fontana, CA", "Santa Clarita, CA",
        "Birmingham, AL", "Oxnard, CA", "Fayetteville, NC", "Rochester, NY", "Moreno Valley, CA",
        "Glendale, CA", "Yonkers, NY", "Huntington Beach, CA", "Aurora, IL", "Salt Lake City, UT",
        "Amarillo, TX", "Montgomery, AL", "Little Rock, AR", "Akron, OH", "Augusta, GA",
        "Grand Rapids, MI", "Mobile, AL", "Tallahassee, FL", "Huntsville, AL", "Knoxville, TN",
        "Worcester, MA", "Brownsville, TX", "Overland Park, KS", "Tempe, AZ", "Providence, RI",
        "Chattanooga, TN", "Newport News, VA", "Fort Lauderdale, FL", "Clarksville, TN",
        "Charleston, WV", "Charleston, SC", "Savannah, GA", "Hartford, CT", "Albany, NY",
        "Dover, DE", "Cheyenne, WY", "Helena, MT", "Bismarck, ND", "Pierre, SD",
        "Concord, NH", "Montpelier, VT", "Augusta, ME", "Trenton, NJ", "Annapolis, MD",
        "Frankfort, KY", "Jackson, MS", "Jefferson City, MO", "Olympia, WA", "Salem, OR",
        "Carson City, NV", "Santa Fe, NM", "Topeka, KS", "Springfield, IL", "Lansing, MI",
        "Harrisburg, PA", "Columbia, SC", "Nashua, NH", "Manchester, NH", "Bridgeport, CT",
        "New Haven, CT", "Stamford, CT", "Wilmington, DE", "Gainesville, FL", "Pensacola, FL",
        "Macon, GA", "Athens, GA", "Idaho Falls, ID", "Sioux City, IA", "Cedar Rapids, IA",
        "Davenport, IA", "Evansville, IN", "South Bend, IN", "Bloomington, IN", "Lawrence, KS",
        "Shreveport, LA", "Lafayette, LA", "Lake Charles, LA", "Portland, ME", "Frederick, MD",
        "Springfield, MA", "Cambridge, MA", "Lowell, MA", "Ann Arbor, MI", "Duluth, MN",
        "Rochester, MN", "Gulfport, MS", "Billings, MT", "Missoula, MT", "Great Falls, MT",
        "Fargo, ND", "Grand Forks, ND", "Lincoln, NE", "Bellevue, NE", "Hoboken, NJ",
        "Paterson, NJ", "Elizabeth, NJ", "Las Cruces, NM", "Syracuse, NY", "Queens, NY",
        "Brooklyn, NY", "Bronx, NY", "Staten Island, NY", "Asheville, NC", "Cary, NC",
        "Fayetteville, AR", "Eugene, OR", "Gresham, OR", "Allentown, PA", "Erie, PA",
        "Scranton, PA", "Pawtucket, RI", "Rapid City, SD", "Sioux Falls, SD", "Clarksville, TN",
        "Murfreesboro, TN", "Chattanooga, TN", "Arlington, VA", "Alexandria, VA", "Roanoke, VA",
        "Burlington, VT", "Vancouver, WA", "Green Bay, WI", "Kenosha, WI", "Racine, WI",
        "Morgantown, WV", "Huntington, WV", "Parkersburg, WV", "Wheeling, WV", "Casper, WY",
    })

    bundled_locations = APP_DIR / "us_locations.txt"
    if bundled_locations.exists():
        try:
            for line in bundled_locations.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    locations.add(line.strip())
        except OSError:
            pass

    optional_csv = APP_DIR / "us_cities.csv"
    if optional_csv.exists():
        try:
            with optional_csv.open("r", newline="", encoding="utf-8-sig") as file:
                reader = csv.DictReader(file)
                for row in reader:
                    city = (row.get("CITY") or row.get("city") or row.get("City") or "").strip()
                    state = (row.get("STATE_CODE") or row.get("state_code") or row.get("state") or row.get("State") or "").strip()
                    if city and state:
                        locations.add(f"{city}, {state}")
        except (OSError, csv.Error):
            pass
    return sorted(locations, key=str.casefold)


class AutocompleteCombobox(ttk.Combobox):
    def __init__(self, master=None, *, complete_values=None, **kwargs):
        self._all_values = list(complete_values or [])
        kwargs.setdefault("values", self._all_values)
        kwargs.setdefault("state", "normal")
        super().__init__(master, **kwargs)
        self.bind("<KeyRelease>", self._filter_values, add="+")
        self.bind("<FocusIn>", self._show_all, add="+")

    def set_complete_values(self, values):
        self._all_values = sorted(set(values), key=str.casefold)
        self.configure(values=self._all_values)

    def _show_all(self, _event=None):
        if not self.get().strip():
            self.configure(values=self._all_values)

    def _filter_values(self, event=None):
        if event and event.keysym in {"Up", "Down", "Left", "Right", "Return", "Escape", "Tab"}:
            return
        typed = self.get().strip().casefold()
        if not typed:
            matches = self._all_values
        else:
            starts = [v for v in self._all_values if v.casefold().startswith(typed)]
            contains = [v for v in self._all_values if typed in v.casefold() and v not in starts]
            matches = (starts + contains)[:250]
        self.configure(values=matches)
        if matches and typed:
            self.event_generate("<Down>")


class Database:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.connection = sqlite3.connect(self.db_path)
        self.connection.row_factory = sqlite3.Row
        self.create_schema()

    def create_schema(self) -> None:
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company TEXT NOT NULL,
                job_title TEXT NOT NULL,
                job_description TEXT,
                pay_disclosed TEXT,
                platform TEXT,
                job_url TEXT,
                resume_used TEXT,
                document_used TEXT,
                applied_at TEXT,
                status TEXT,
                recruiter_name TEXT,
                recruiter_email TEXT,
                recruiter_phone TEXT,
                contact_method TEXT,
                location TEXT,
                work_arrangement TEXT,
                employment_type TEXT,
                application_id TEXT,
                follow_up_date TEXT,
                interview_date TEXT,
                notes TEXT,
                job_description_file TEXT,
                resume_file TEXT,
                cover_letter_file TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS application_notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                application_id INTEGER NOT NULL,
                note_date TEXT NOT NULL,
                subject TEXT,
                note_text TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(application_id) REFERENCES applications(id)
            );

            CREATE TABLE IF NOT EXISTS application_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                application_id INTEGER NOT NULL,
                document_name TEXT NOT NULL,
                file_path TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(application_id) REFERENCES applications(id)
            );

            CREATE TABLE IF NOT EXISTS clarification_questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                application_id INTEGER NOT NULL,
                question_text TEXT NOT NULL,
                answer_text TEXT,
                status TEXT NOT NULL DEFAULT 'Open',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(application_id) REFERENCES applications(id)
            );

            CREATE INDEX IF NOT EXISTS idx_applications_company ON applications(company);
            CREATE INDEX IF NOT EXISTS idx_applications_title ON applications(job_title);
            CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);
            CREATE INDEX IF NOT EXISTS idx_applications_applied_at ON applications(applied_at);
            CREATE INDEX IF NOT EXISTS idx_notes_application_id ON application_notes(application_id);
            CREATE INDEX IF NOT EXISTS idx_documents_application_id ON application_documents(application_id);
            CREATE INDEX IF NOT EXISTS idx_questions_application_id ON clarification_questions(application_id);
            CREATE INDEX IF NOT EXISTS idx_questions_status ON clarification_questions(status);
            """
        )
        self.connection.commit()

    def insert(self, record: dict) -> int:
        columns = ", ".join(record.keys())
        placeholders = ", ".join("?" for _ in record)
        cursor = self.connection.execute(
            f"INSERT INTO applications ({columns}) VALUES ({placeholders})",
            tuple(record.values()),
        )
        self.connection.commit()
        return int(cursor.lastrowid)

    def update(self, application_id: int, record: dict) -> None:
        assignments = ", ".join(f"{key} = ?" for key in record)
        values = list(record.values()) + [application_id]
        self.connection.execute(
            f"UPDATE applications SET {assignments} WHERE id = ?", values
        )
        self.connection.commit()

    def delete(self, application_id: int) -> None:
        self.connection.execute("DELETE FROM application_notes WHERE application_id = ?", (application_id,))
        self.connection.execute("DELETE FROM application_documents WHERE application_id = ?", (application_id,))
        self.connection.execute("DELETE FROM clarification_questions WHERE application_id = ?", (application_id,))
        self.connection.execute("DELETE FROM applications WHERE id = ?", (application_id,))
        self.connection.commit()

    def get(self, application_id: int) -> sqlite3.Row | None:
        return self.connection.execute(
            "SELECT * FROM applications WHERE id = ?", (application_id,)
        ).fetchone()

    def search(self, keyword: str = "", status: str = "", platform: str = "",
               follow_up_filter: str = "", order_by: str = "applied_at",
               descending: bool = True) -> list[sqlite3.Row]:
        query = """
            SELECT applications.*,
                   (SELECT COUNT(*)
                    FROM clarification_questions q_count
                    WHERE q_count.application_id = applications.id
                      AND q_count.status = 'Open') AS open_question_count
            FROM applications
            WHERE 1 = 1
        """
        params: list[str] = []
        if keyword.strip():
            value = f"%{keyword.strip()}%"
            query += """
                AND (
                    company LIKE ? OR job_title LIKE ? OR recruiter_name LIKE ?
                    OR recruiter_email LIKE ? OR recruiter_phone LIKE ?
                    OR location LIKE ? OR notes LIKE ? OR job_description LIKE ?
                    OR application_id LIKE ? OR job_url LIKE ? OR resume_used LIKE ?
                    OR platform LIKE ? OR EXISTS (
                        SELECT 1 FROM application_notes n
                        WHERE n.application_id = applications.id
                          AND (n.subject LIKE ? OR n.note_text LIKE ?)
                    ) OR EXISTS (
                        SELECT 1 FROM clarification_questions q
                        WHERE q.application_id = applications.id
                          AND (q.question_text LIKE ? OR q.answer_text LIKE ?)
                    )
                )
            """
            params.extend([value] * 16)
        if status:
            query += " AND status = ?"
            params.append(status)
        if platform:
            query += " AND platform = ?"
            params.append(platform)

        open_status_placeholders = ", ".join("?" for _ in TERMINAL_STATUSES)
        if follow_up_filter == "Overdue":
            query += (
                f" AND TRIM(COALESCE(follow_up_date, '')) <> ''"
                f" AND date(follow_up_date) < date('now', 'localtime')"
                f" AND COALESCE(status, '') NOT IN ({open_status_placeholders})"
            )
            params.extend(sorted(TERMINAL_STATUSES))
        elif follow_up_filter == "Due Today":
            query += (
                f" AND date(follow_up_date) = date('now', 'localtime')"
                f" AND COALESCE(status, '') NOT IN ({open_status_placeholders})"
            )
            params.extend(sorted(TERMINAL_STATUSES))
        elif follow_up_filter == "Upcoming":
            query += (
                f" AND date(follow_up_date) > date('now', 'localtime')"
                f" AND COALESCE(status, '') NOT IN ({open_status_placeholders})"
            )
            params.extend(sorted(TERMINAL_STATUSES))
        elif follow_up_filter == "No Date":
            query += " AND TRIM(COALESCE(follow_up_date, '')) = ''"

        allowed = {
            "id", "company", "job_title", "applied_at", "platform",
            "pay_disclosed", "resume_used", "recruiter_name", "follow_up_date", "status",
            "open_question_count"
        }
        sort_column = order_by if order_by in allowed else "applied_at"
        direction = "DESC" if descending else "ASC"
        if sort_column in {"applied_at", "follow_up_date"}:
            query += f" ORDER BY CASE WHEN {sort_column} = '' OR {sort_column} IS NULL THEN 1 ELSE 0 END, datetime({sort_column}) {direction}, id DESC"
        elif sort_column in {"id", "open_question_count"}:
            query += f" ORDER BY {sort_column} {direction}, id DESC"
        else:
            query += f" ORDER BY LOWER(COALESCE({sort_column}, '')) {direction}, id DESC"
        return list(self.connection.execute(query, params).fetchall())

    def all_rows(self) -> list[sqlite3.Row]:
        return list(self.connection.execute("SELECT * FROM applications ORDER BY id").fetchall())

    def counts(self) -> dict[str, int]:
        terminal = tuple(sorted(TERMINAL_STATUSES))
        placeholders = ", ".join("?" for _ in terminal)
        row = self.connection.execute(
            f"""
            SELECT COUNT(*) AS total,
                SUM(CASE WHEN status = 'Applied' THEN 1 ELSE 0 END) AS applied,
                SUM(CASE WHEN status IN (
                    'Recruiter Contacted','Phone Screen','Interview Scheduled',
                    'Interview Completed','Assessment'
                ) THEN 1 ELSE 0 END) AS active,
                SUM(CASE WHEN status IN ('Offer', 'Accepted') THEN 1 ELSE 0 END) AS offers,
                SUM(CASE WHEN date(follow_up_date) = date('now', 'localtime')
                    AND COALESCE(status, '') NOT IN ({placeholders}) THEN 1 ELSE 0 END) AS due_today,
                SUM(CASE WHEN TRIM(COALESCE(follow_up_date, '')) <> ''
                    AND date(follow_up_date) < date('now', 'localtime')
                    AND COALESCE(status, '') NOT IN ({placeholders}) THEN 1 ELSE 0 END) AS overdue,
                (SELECT COUNT(*) FROM clarification_questions WHERE status = 'Open') AS open_questions
            FROM applications
            """,
            terminal + terminal,
        ).fetchone()
        keys = ("total", "applied", "active", "offers", "due_today", "overdue", "open_questions")
        return {key: int(row[key] or 0) for key in keys}

    def backup_to(self, destination: Path) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(destination) as backup_connection:
            self.connection.backup(backup_connection)

    def get_notes(self, application_id: int) -> list[sqlite3.Row]:
        return list(self.connection.execute(
            "SELECT * FROM application_notes WHERE application_id = ? ORDER BY datetime(note_date) DESC, id DESC",
            (application_id,)
        ).fetchall())

    def add_note(self, application_id: int, note_date: str, subject: str, note_text: str) -> None:
        self.connection.execute(
            """
            INSERT INTO application_notes(application_id, note_date, subject, note_text, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (application_id, note_date, subject, note_text, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        )
        self.connection.commit()

    def update_note(self, note_id: int, note_date: str, subject: str, note_text: str) -> None:
        self.connection.execute(
            "UPDATE application_notes SET note_date = ?, subject = ?, note_text = ? WHERE id = ?",
            (note_date, subject, note_text, note_id)
        )
        self.connection.commit()

    def delete_note(self, note_id: int) -> None:
        self.connection.execute("DELETE FROM application_notes WHERE id = ?", (note_id,))
        self.connection.commit()

    def get_documents(self, application_id: int) -> list[sqlite3.Row]:
        return list(self.connection.execute(
            "SELECT * FROM application_documents WHERE application_id = ? ORDER BY id DESC",
            (application_id,)
        ).fetchall())

    def add_document(self, application_id: int, name: str, path: str) -> None:
        self.connection.execute(
            """
            INSERT INTO application_documents(application_id, document_name, file_path, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (application_id, name, path, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        )
        self.connection.commit()

    def delete_document(self, document_id: int) -> None:
        self.connection.execute("DELETE FROM application_documents WHERE id = ?", (document_id,))
        self.connection.commit()

    def follow_up_rows(self, filter_name: str = "All Active") -> list[sqlite3.Row]:
        query = """
            SELECT id, company, job_title, status, applied_at, follow_up_date,
                   recruiter_name, recruiter_email, job_url
            FROM applications
            WHERE COALESCE(status, '') NOT IN (?, ?, ?, ?)
        """
        params: list[str] = sorted(TERMINAL_STATUSES)
        if filter_name == "Overdue":
            query += " AND TRIM(COALESCE(follow_up_date, '')) <> '' AND date(follow_up_date) < date('now', 'localtime')"
        elif filter_name == "Due Today":
            query += " AND date(follow_up_date) = date('now', 'localtime')"
        elif filter_name == "Upcoming":
            query += " AND date(follow_up_date) > date('now', 'localtime')"
        elif filter_name == "No Date":
            query += " AND TRIM(COALESCE(follow_up_date, '')) = ''"
        query += " ORDER BY CASE WHEN TRIM(COALESCE(follow_up_date, '')) = '' THEN 1 ELSE 0 END, date(follow_up_date), id DESC"
        return list(self.connection.execute(query, params).fetchall())

    def set_follow_up_date(self, application_id: int, follow_up_date: str) -> None:
        self.connection.execute(
            "UPDATE applications SET follow_up_date = ?, updated_at = ? WHERE id = ?",
            (follow_up_date, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), application_id),
        )
        self.connection.commit()

    def set_missing_followups(self, days: int = 7) -> int:
        rows = self.connection.execute(
            """
            SELECT id, applied_at FROM applications
            WHERE TRIM(COALESCE(follow_up_date, '')) = ''
              AND COALESCE(status, '') NOT IN (?, ?, ?, ?)
            """,
            tuple(sorted(TERMINAL_STATUSES)),
        ).fetchall()
        updated = 0
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for row in rows:
            follow_up = default_follow_up_date(row["applied_at"] or "", days)
            if follow_up:
                self.connection.execute(
                    "UPDATE applications SET follow_up_date = ?, updated_at = ? WHERE id = ?",
                    (follow_up, now, row["id"]),
                )
                updated += 1
        self.connection.commit()
        return updated

    def application_choices(self) -> list[sqlite3.Row]:
        return list(self.connection.execute(
            "SELECT id, company, job_title, status FROM applications ORDER BY LOWER(company), LOWER(job_title), id"
        ).fetchall())

    def get_questions(self, status_filter: str = "") -> list[sqlite3.Row]:
        query = """
            SELECT q.*, a.company, a.job_title
            FROM clarification_questions q
            JOIN applications a ON a.id = q.application_id
            WHERE 1 = 1
        """
        params: list[str] = []
        if status_filter:
            query += " AND q.status = ?"
            params.append(status_filter)
        query += " ORDER BY CASE q.status WHEN 'Open' THEN 0 WHEN 'Answered' THEN 1 ELSE 2 END, datetime(q.updated_at) DESC, q.id DESC"
        return list(self.connection.execute(query, params).fetchall())

    def get_questions_for_application(
        self, application_id: int, status_filter: str = "",
        order_by: str = "id", descending: bool = False
    ) -> list[sqlite3.Row]:
        query = "SELECT * FROM clarification_questions WHERE application_id = ?"
        params: list[object] = [application_id]
        if status_filter:
            query += " AND status = ?"
            params.append(status_filter)
        allowed = {"id", "question_text", "status", "answer_text", "updated_at"}
        sort_column = order_by if order_by in allowed else "id"
        direction = "DESC" if descending else "ASC"
        if sort_column == "id":
            query += f" ORDER BY id {direction}"
        elif sort_column == "updated_at":
            query += f" ORDER BY datetime(updated_at) {direction}, id DESC"
        else:
            query += f" ORDER BY LOWER(COALESCE({sort_column}, '')) {direction}, id DESC"
        return list(self.connection.execute(query, params).fetchall())

    def get_question(self, question_id: int) -> sqlite3.Row | None:
        return self.connection.execute(
            "SELECT * FROM clarification_questions WHERE id = ?", (question_id,)
        ).fetchone()

    def add_question(self, application_id: int, question_text: str, answer_text: str = "", status: str = "Open") -> None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.connection.execute(
            """
            INSERT INTO clarification_questions(application_id, question_text, answer_text, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (application_id, question_text, answer_text, status, now, now),
        )
        self.connection.commit()

    def update_question(self, question_id: int, question_text: str, answer_text: str, status: str) -> None:
        self.connection.execute(
            """
            UPDATE clarification_questions
            SET question_text = ?, answer_text = ?, status = ?, updated_at = ?
            WHERE id = ?
            """,
            (question_text, answer_text, status, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), question_id),
        )
        self.connection.commit()

    def delete_question(self, question_id: int) -> None:
        self.connection.execute("DELETE FROM clarification_questions WHERE id = ?", (question_id,))
        self.connection.commit()

    def question_export_text(self, application_id: int) -> tuple[str, str]:
        rows = self.connection.execute(
            """
            SELECT question_text, answer_text, status
            FROM clarification_questions
            WHERE application_id = ?
            ORDER BY id
            """,
            (application_id,),
        ).fetchall()
        questions = []
        answers = []
        for row in rows:
            questions.append(f"[{row['status']}] {row['question_text']}")
            if (row["answer_text"] or "").strip():
                answers.append(f"{row['question_text']}: {row['answer_text']}")
        return " | ".join(questions), " | ".join(answers)

    def close(self) -> None:
        self.connection.close()


class ScrollableFrame(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        canvas = tk.Canvas(self, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        self.content = ttk.Frame(canvas)
        self.content.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        window_id = canvas.create_window((0, 0), window=self.content, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window_id, width=e.width))
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")


class ApplicationForm(ttk.Frame):
    def __init__(self, parent, db: Database, on_saved, on_cancel):
        super().__init__(parent, padding=12)
        self.db = db
        self.on_saved = on_saved
        self.on_cancel = on_cancel
        self.current_id: int | None = None

        self.vars = {key: tk.StringVar() for key in [
            "company","job_title","pay_disclosed","platform","job_url","resume_used",
            "document_used","applied_at","status","recruiter_name","recruiter_email",
            "recruiter_phone","contact_method","location","work_arrangement",
            "employment_type","application_id","follow_up_date","interview_date"
        ]}
        self.vars["status"].set("Applied")
        self.job_description_file_var = tk.StringVar()
        self.custom_doc_name_var = tk.StringVar()
        self.custom_doc_path_var = tk.StringVar()
        self.question_filter_var = tk.StringVar()
        self.question_sort_column = "id"
        self.question_sort_descending = False
        self.question_column_labels = {
            "id": "ID",
            "question_text": "Question",
            "status": "Status",
            "answer_text": "Confirmed Answer",
        }

        self._build()

    def _build(self):
        header = ttk.Frame(self)
        header.pack(fill="x", pady=(0, 10))
        self.title_label = ttk.Label(header, text="Add Job Application", font=("TkDefaultFont", 16, "bold"))
        self.title_label.pack(side="left")
        ttk.Button(header, text="Save", command=self._save).pack(side="right", padx=(5,0))
        ttk.Button(header, text="Cancel", command=self.on_cancel).pack(side="right")

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True)

        job_tab = ScrollableFrame(notebook)
        timeline_tab = ScrollableFrame(notebook)
        followups_tab = ttk.Frame(notebook, padding=10)
        docs_tab = ScrollableFrame(notebook)
        notes_tab = ttk.Frame(notebook, padding=10)

        notebook.add(job_tab, text="Job")
        notebook.add(timeline_tab, text="Recruiter & Timeline")
        notebook.add(followups_tab, text="Follow-Ups & Questions")
        notebook.add(docs_tab, text="Documents")
        notebook.add(notes_tab, text="Description & Notes")

        self._build_job_tab(job_tab.content)
        self._build_timeline_tab(timeline_tab.content)
        self._build_followups_tab(followups_tab)
        self._build_documents_tab(docs_tab.content)
        self._build_notes_tab(notes_tab)

    def _entry(self, parent, row, label, key):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0,8), pady=5)
        ttk.Entry(parent, textvariable=self.vars[key]).grid(row=row, column=1, sticky="ew", pady=5)

    def _combo(self, parent, row, label, key, values):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0,8), pady=5)
        ttk.Combobox(parent, textvariable=self.vars[key], values=values).grid(row=row, column=1, sticky="ew", pady=5)

    def _build_job_tab(self, parent):
        parent.columnconfigure(1, weight=1)
        self._entry(parent, 0, "Company *", "company")
        self._entry(parent, 1, "Job title *", "job_title")
        self._combo(parent, 2, "Status", "status", STATUSES)
        self._combo(parent, 3, "Platform", "platform", PLATFORMS)
        self._entry(parent, 4, "Job posting URL", "job_url")
        self._entry(parent, 5, "Pay disclosed (optional)", "pay_disclosed")
        ttk.Label(parent, text="Location").grid(row=6, column=0, sticky="w", padx=(0,8), pady=5)
        location_values = load_us_locations()
        # Include locations already used in the database so they become future suggestions.
        try:
            location_values.extend(row["location"] for row in self.db.all_rows() if row["location"])
        except sqlite3.Error:
            pass
        self.location_combo = AutocompleteCombobox(
            parent, textvariable=self.vars["location"], complete_values=location_values
        )
        self.location_combo.grid(row=6, column=1, sticky="ew", pady=5)
        self._combo(parent, 7, "Work arrangement", "work_arrangement", WORK_ARRANGEMENTS)
        self._combo(parent, 8, "Employment type", "employment_type", EMPLOYMENT_TYPES)
        self._entry(parent, 9, "Application / requisition ID", "application_id")

    def _build_timeline_tab(self, parent):
        parent.columnconfigure(1, weight=1)
        self._entry(parent, 0, "Applied date", "applied_at")
        ttk.Button(
            parent, text="Use Current Date",
            command=lambda: self.vars["applied_at"].set(datetime.now().strftime("%Y-%m-%d"))
        ).grid(row=1, column=1, sticky="w", pady=(0,10))
        self._entry(parent, 2, "Recruiter name", "recruiter_name")
        self._entry(parent, 3, "Recruiter email", "recruiter_email")
        self._entry(parent, 4, "Recruiter phone", "recruiter_phone")
        self._entry(parent, 5, "Contact method", "contact_method")
        self._entry(parent, 6, "Interview date & time", "interview_date")

    def _build_followups_tab(self, parent):
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(2, weight=1)

        follow_frame = ttk.LabelFrame(parent, text="Follow-Up", padding=10)
        follow_frame.grid(row=0, column=0, sticky="ew", pady=(0,10))
        follow_frame.columnconfigure(1, weight=1)
        ttk.Label(follow_frame, text="Follow-Up Date").grid(
            row=0, column=0, sticky="w", padx=(0,8), pady=5
        )
        follow_up_row = ttk.Frame(follow_frame)
        follow_up_row.grid(row=0, column=1, sticky="ew", pady=5)
        follow_up_row.columnconfigure(0, weight=1)
        ttk.Entry(follow_up_row, textvariable=self.vars["follow_up_date"]).grid(
            row=0, column=0, sticky="ew"
        )
        ttk.Button(
            follow_up_row, text="Today",
            command=lambda: self.vars["follow_up_date"].set(date.today().isoformat())
        ).grid(row=0, column=1, padx=(6,0))
        ttk.Button(
            follow_up_row, text="+3 Days",
            command=lambda: self.vars["follow_up_date"].set(
                (date.today() + timedelta(days=3)).isoformat()
            )
        ).grid(row=0, column=2, padx=(6,0))
        ttk.Button(
            follow_up_row, text="+7 Days",
            command=lambda: self.vars["follow_up_date"].set(
                (date.today() + timedelta(days=7)).isoformat()
            )
        ).grid(row=0, column=3, padx=(6,0))
        ttk.Button(
            follow_up_row, text="Applied +7", command=self._set_follow_up_from_applied
        ).grid(row=0, column=4, padx=(6,0))
        ttk.Button(
            follow_up_row, text="Clear",
            command=lambda: self.vars["follow_up_date"].set("")
        ).grid(row=0, column=5, padx=(6,0))
        ttk.Label(
            follow_frame,
            text="Active applications receive Applied Date +7 automatically when this field is blank."
        ).grid(row=1, column=1, sticky="w", pady=(0,4))

        question_controls = ttk.Frame(parent)
        question_controls.grid(row=1, column=0, sticky="ew", pady=(0,6))
        ttk.Label(question_controls, text="Clarification Questions").pack(side="left")
        ttk.Label(question_controls, text="Show").pack(side="left", padx=(18,4))
        question_filter = ttk.Combobox(
            question_controls, textvariable=self.question_filter_var,
            values=[""] + QUESTION_STATUSES, state="readonly", width=12
        )
        question_filter.pack(side="left")
        question_filter.bind("<<ComboboxSelected>>", lambda event: self._refresh_questions())
        ttk.Button(question_controls, text="Add Question", command=self._add_question).pack(side="right", padx=(5,0))
        ttk.Button(question_controls, text="Edit / Answer", command=self._edit_question).pack(side="right", padx=(5,0))
        ttk.Button(question_controls, text="Mark Not Needed", command=self._mark_question_not_needed).pack(side="right", padx=(5,0))
        ttk.Button(question_controls, text="Delete", command=self._delete_question).pack(side="right")

        question_frame = ttk.Frame(parent)
        question_frame.grid(row=2, column=0, sticky="nsew")
        question_frame.columnconfigure(0, weight=1)
        question_frame.rowconfigure(0, weight=1)
        columns = ("id", "question_text", "status", "answer_text")
        self.questions_tree = ttk.Treeview(
            question_frame, columns=columns, show="headings", selectmode="browse"
        )
        widths = {"id":55, "question_text":360, "status":100, "answer_text":360}
        for column in columns:
            self.questions_tree.column(
                column, width=widths[column], minwidth=55, stretch=(column in {"question_text", "answer_text"})
            )
        self._update_question_headings()
        y_scroll = ttk.Scrollbar(question_frame, orient="vertical", command=self.questions_tree.yview)
        x_scroll = ttk.Scrollbar(question_frame, orient="horizontal", command=self.questions_tree.xview)
        self.questions_tree.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)
        self.questions_tree.grid(row=0, column=0, sticky="nsew")
        y_scroll.grid(row=0, column=1, sticky="ns")
        x_scroll.grid(row=1, column=0, sticky="ew")
        self.questions_tree.bind("<Double-1>", lambda event: self._edit_question())
        self.questions_tree.bind("<Return>", lambda event: self._edit_question())

        ttk.Label(
            parent,
            text="Use this section for information that still needs confirmation; keep factual recruiter activity in Notes."
        ).grid(row=3, column=0, sticky="w", pady=(6,0))

    def _set_follow_up_from_applied(self):
        follow_up = default_follow_up_date(self.vars["applied_at"].get())
        if not follow_up:
            messagebox.showinfo(APP_NAME, "Enter the applied date as YYYY-MM-DD first.")
            return
        self.vars["follow_up_date"].set(follow_up)

    def _selected_question_id(self) -> int | None:
        selected = self.questions_tree.selection()
        return int(selected[0]) if selected else None

    def _update_question_headings(self):
        if not hasattr(self, "questions_tree"):
            return
        for column, label in self.question_column_labels.items():
            indicator = ""
            if column == self.question_sort_column:
                indicator = " \u25bc" if self.question_sort_descending else " \u25b2"
            self.questions_tree.heading(
                column, text=label + indicator,
                command=lambda col=column: self._sort_questions_by(col)
            )

    def _sort_questions_by(self, column: str):
        if self.question_sort_column == column:
            self.question_sort_descending = not self.question_sort_descending
        else:
            self.question_sort_column = column
            self.question_sort_descending = column == "id"
        self._refresh_questions()

    def _add_question(self):
        if not self._ensure_saved():
            return
        question = simpledialog.askstring(
            APP_NAME,
            "Enter the clarification question to ask the recruiter or employer:",
            parent=self.winfo_toplevel(),
        )
        if not question or not question.strip():
            return
        self.db.add_question(self.current_id, question.strip())
        self.question_filter_var.set("")
        self._refresh_questions()
        self.on_saved()

    def _edit_question(self):
        question_id = self._selected_question_id()
        if question_id is None:
            messagebox.showinfo(APP_NAME, "Select a clarification question first.", parent=self.winfo_toplevel())
            return
        row = self.db.get_question(question_id)
        if row is None:
            return
        question = simpledialog.askstring(
            APP_NAME, "Clarification question:",
            initialvalue=row["question_text"] or "", parent=self.winfo_toplevel()
        )
        if question is None or not question.strip():
            return
        answer = simpledialog.askstring(
            APP_NAME, "Confirmed answer (leave blank if still unanswered):",
            initialvalue=row["answer_text"] or "", parent=self.winfo_toplevel()
        )
        if answer is None:
            return
        if answer.strip():
            status = "Answered"
        elif row["status"] == "Not Needed":
            status = "Not Needed"
        else:
            status = "Open"
        self.db.update_question(question_id, question.strip(), answer.strip(), status)
        self._refresh_questions()
        self.on_saved()

    def _mark_question_not_needed(self):
        question_id = self._selected_question_id()
        if question_id is None:
            messagebox.showinfo(APP_NAME, "Select a clarification question first.", parent=self.winfo_toplevel())
            return
        row = self.db.get_question(question_id)
        if row is None:
            return
        self.db.update_question(
            question_id, row["question_text"] or "", row["answer_text"] or "", "Not Needed"
        )
        self._refresh_questions()
        self.on_saved()

    def _delete_question(self):
        question_id = self._selected_question_id()
        if question_id is None:
            messagebox.showinfo(APP_NAME, "Select a clarification question first.", parent=self.winfo_toplevel())
            return
        if messagebox.askyesno(APP_NAME, "Delete the selected clarification question?", parent=self.winfo_toplevel()):
            self.db.delete_question(question_id)
            self._refresh_questions()
            self.on_saved()

    def _refresh_questions(self):
        if not hasattr(self, "questions_tree"):
            return
        for item in self.questions_tree.get_children():
            self.questions_tree.delete(item)
        if self.current_id is None:
            self._update_question_headings()
            return
        rows = self.db.get_questions_for_application(
            self.current_id, self.question_filter_var.get(),
            self.question_sort_column, self.question_sort_descending
        )
        for row in rows:
            question = " ".join((row["question_text"] or "").split())
            answer = " ".join((row["answer_text"] or "").split())
            self.questions_tree.insert(
                "", "end", iid=str(row["id"]),
                values=(row["id"], question, row["status"], answer)
            )
        self._update_question_headings()

    def _build_documents_tab(self, parent):
        parent.columnconfigure(1, weight=1)
        self._combo(parent, 0, "Resume used", "resume_used", load_resume_choices())
        self._combo(parent, 1, "CV / cover letter used", "document_used", DOCUMENT_OPTIONS)

        ttk.Separator(parent).grid(row=2, column=0, columnspan=2, sticky="ew", pady=12)

        ttk.Label(parent, text="CV / cover letter details").grid(row=3, column=0, sticky="nw", padx=(0,8), pady=5)
        self.application_materials_text = tk.Text(parent, height=5, wrap="word")
        self.application_materials_text.grid(row=3, column=1, sticky="ew", pady=5)
        ttk.Label(parent, text="Paste the cover-letter text, CV notes, or other application-material details here.").grid(
            row=4, column=1, sticky="w", pady=(0,8)
        )

        ttk.Label(parent, text="Custom document name").grid(row=5, column=0, sticky="w", padx=(0,8), pady=5)
        ttk.Entry(parent, textvariable=self.custom_doc_name_var).grid(row=5, column=1, sticky="ew", pady=5)

        ttk.Label(parent, text="Custom document file").grid(row=6, column=0, sticky="w", padx=(0,8), pady=5)
        custom_row = ttk.Frame(parent)
        custom_row.grid(row=6, column=1, sticky="ew", pady=5)
        custom_row.columnconfigure(0, weight=1)
        ttk.Entry(custom_row, textvariable=self.custom_doc_path_var).grid(row=0, column=0, sticky="ew")
        ttk.Button(custom_row, text="Browse", command=self._browse_custom_document).grid(row=0, column=1, padx=(6,0))
        ttk.Button(custom_row, text="Add Document", command=self._add_document).grid(row=0, column=2, padx=(6,0))

        ttk.Label(parent, text="Saved documents").grid(row=7, column=0, sticky="nw", padx=(0,8), pady=5)
        docs_frame = ttk.Frame(parent)
        docs_frame.grid(row=7, column=1, sticky="nsew", pady=5)
        docs_frame.columnconfigure(0, weight=1)
        self.documents_tree = ttk.Treeview(docs_frame, columns=("name","path"), show="headings", height=8)
        self.documents_tree.heading("name", text="Document Name")
        self.documents_tree.heading("path", text="File")
        self.documents_tree.column("name", width=180)
        self.documents_tree.column("path", width=380)
        self.documents_tree.grid(row=0, column=0, columnspan=3, sticky="nsew")
        ttk.Button(docs_frame, text="Open", command=self._open_selected_document).grid(row=1, column=0, sticky="w", pady=6)
        ttk.Button(docs_frame, text="Remove", command=self._remove_selected_document).grid(row=1, column=1, sticky="w", pady=6)

    def _build_notes_tab(self, parent):
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(1, weight=1)
        parent.rowconfigure(4, weight=1)

        ttk.Label(parent, text="Job description").grid(row=0, column=0, sticky="w")
        self.description_text = tk.Text(parent, height=12, wrap="word")
        self.description_text.grid(row=1, column=0, sticky="nsew", pady=(4,10))

        controls = ttk.Frame(parent)
        controls.grid(row=2, column=0, sticky="ew", pady=(0,6))
        ttk.Label(controls, text="Communication / activity notes").pack(side="left")
        ttk.Button(controls, text="Add Note", command=self._add_note).pack(side="right", padx=(5,0))
        ttk.Button(controls, text="Edit Note", command=self._edit_note).pack(side="right", padx=(5,0))
        ttk.Button(controls, text="Delete Note", command=self._delete_note).pack(side="right")

        self.notes_tree = ttk.Treeview(parent, columns=("date","subject","note"), show="headings", height=10)
        self.notes_tree.heading("date", text="Date / Time")
        self.notes_tree.heading("subject", text="Subject")
        self.notes_tree.heading("note", text="Note")
        self.notes_tree.column("date", width=140)
        self.notes_tree.column("subject", width=190)
        self.notes_tree.column("note", width=500)
        self.notes_tree.grid(row=4, column=0, sticky="nsew")
        self.notes_tree.bind("<Double-1>", lambda event: self._edit_note())
        self.notes_tree.bind("<Return>", lambda event: self._edit_note())

        ttk.Label(parent, text="Notes are optional. Add only confirmed recruiter contacts, responses, interviews, assessments, or other useful facts.").grid(row=5, column=0, sticky="w", pady=(6,0))

    def _ensure_saved(self) -> bool:
        if self.current_id is not None:
            return True
        if not self.vars["company"].get().strip() or not self.vars["job_title"].get().strip():
            messagebox.showinfo(APP_NAME, "Enter the company and job title, then click Save before adding notes, questions, or custom documents.")
            return False
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = self._collect_record()
        record["created_at"] = now
        record["updated_at"] = now
        self.current_id = self.db.insert(record)
        self.title_label.configure(text=f"Edit Application #{self.current_id}")
        self.on_saved()
        return True

    def _collect_record(self) -> dict:
        record = {key: var.get().strip() for key, var in self.vars.items()}
        if not record["follow_up_date"] and record["status"] not in TERMINAL_STATUSES:
            record["follow_up_date"] = default_follow_up_date(record["applied_at"])
            self.vars["follow_up_date"].set(record["follow_up_date"])
        record["job_description"] = self.description_text.get("1.0", "end").strip()
        record["notes"] = ""
        record["job_description_file"] = self.application_materials_text.get("1.0", "end").strip()
        record["resume_file"] = ""
        record["cover_letter_file"] = ""
        return record

    def save_record(self, close_after=True, show_message=True):
        if not self.vars["company"].get().strip() or not self.vars["job_title"].get().strip():
            messagebox.showerror(APP_NAME, "Company and job title are required.")
            return False
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = self._collect_record()
        record["updated_at"] = now
        if self.current_id is None:
            record["created_at"] = now
            self.current_id = self.db.insert(record)
            self.title_label.configure(text=f"Edit Application #{self.current_id}")
        else:
            self.db.update(self.current_id, record)
        self.on_saved()
        if show_message:
            messagebox.showinfo(APP_NAME, "Application saved successfully.")
        if close_after:
            self.on_cancel()
        return True

    def _save(self):
        self.save_record(close_after=True, show_message=True)

    def _browse_job_description(self):
        path = filedialog.askopenfilename(title="Select job description file")
        if path:
            self.job_description_file_var.set(path)

    def _browse_custom_document(self):
        path = filedialog.askopenfilename(title="Select document")
        if path:
            self.custom_doc_path_var.set(path)

    def _copy_attachment(self, source_path: str, label: str) -> str:
        source = Path(source_path)
        if not source.exists() or self.current_id is None:
            return source_path
        folder = ATTACHMENTS_DIR / f"application_{self.current_id}"
        folder.mkdir(parents=True, exist_ok=True)
        safe_label = "".join(c if c.isalnum() or c in "-_ " else "_" for c in label).strip() or "document"
        target = folder / f"{safe_label}{source.suffix.lower()}"
        counter = 2
        while target.exists() and source.resolve() != target.resolve():
            target = folder / f"{safe_label}_{counter}{source.suffix.lower()}"
            counter += 1
        if source.resolve() != target.resolve():
            shutil.copy2(source, target)
        return str(target)

    def _add_document(self):
        if not self._ensure_saved():
            return
        name = self.custom_doc_name_var.get().strip()
        path = self.custom_doc_path_var.get().strip()
        if not name:
            messagebox.showerror(APP_NAME, "Enter a document name.")
            return
        if path:
            try:
                path = self._copy_attachment(path, name)
            except Exception as error:
                messagebox.showwarning(APP_NAME, f"Document name will be saved, but the file could not be copied:\n{error}")
        self.db.add_document(self.current_id, name, path)
        self.custom_doc_name_var.set("")
        self.custom_doc_path_var.set("")
        self._refresh_documents()

    def _open_selected_document(self):
        selected = self.documents_tree.selection()
        if not selected:
            return
        path = self.documents_tree.item(selected[0], "values")[1]
        if not path:
            messagebox.showinfo(APP_NAME, "This document entry has no attached file.")
            return
        self._open_path(path)

    def _remove_selected_document(self):
        selected = self.documents_tree.selection()
        if not selected:
            return
        self.db.delete_document(int(selected[0]))
        self._refresh_documents()

    def _open_path(self, value):
        path = Path(value)
        if not path.exists():
            messagebox.showerror(APP_NAME, f"File not found:\n{path}")
            return
        if sys.platform.startswith("win"):
            os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=False)
        else:
            subprocess.run(["xdg-open", str(path)], check=False)

    def _note_dialog(self, title, existing=None):
        dialog = tk.Toplevel(self)
        dialog.title(title)
        dialog.geometry("700x520")
        dialog.minsize(560, 420)
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()

        dialog.columnconfigure(0, weight=1)
        dialog.rowconfigure(5, weight=1)

        date_var = tk.StringVar(
            value=(existing["note_date"] if existing else datetime.now().strftime("%Y-%m-%d %H:%M"))
        )
        subject_var = tk.StringVar(value=(existing["subject"] if existing else ""))

        ttk.Label(dialog, text="Date / Time").grid(
            row=0, column=0, sticky="w", padx=12, pady=(12, 2)
        )
        ttk.Entry(dialog, textvariable=date_var).grid(
            row=1, column=0, sticky="ew", padx=12
        )

        ttk.Label(dialog, text="Subject").grid(
            row=2, column=0, sticky="w", padx=12, pady=(10, 2)
        )
        ttk.Entry(dialog, textvariable=subject_var).grid(
            row=3, column=0, sticky="ew", padx=12
        )

        ttk.Label(dialog, text="Note").grid(
            row=4, column=0, sticky="w", padx=12, pady=(10, 2)
        )

        text_frame = ttk.Frame(dialog)
        text_frame.grid(row=5, column=0, sticky="nsew", padx=12, pady=(0, 10))
        text_frame.columnconfigure(0, weight=1)
        text_frame.rowconfigure(0, weight=1)

        text = tk.Text(text_frame, wrap="word")
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scrollbar.set)
        text.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        if existing:
            text.insert("1.0", existing["note_text"])

        result = {"value": None}

        def save_note(event=None):
            body = text.get("1.0", "end").strip()
            if not body:
                messagebox.showerror(APP_NAME, "Enter a note.", parent=dialog)
                return "break"
            result["value"] = (
                date_var.get().strip(),
                subject_var.get().strip(),
                body,
            )
            dialog.destroy()
            return "break"

        def cancel_note(event=None):
            dialog.destroy()
            return "break"

        buttons = ttk.Frame(dialog)
        buttons.grid(row=6, column=0, sticky="ew", padx=12, pady=(0, 12))
        ttk.Label(buttons, text="Ctrl+Enter saves the note.").pack(side="left")
        ttk.Button(buttons, text="Cancel", command=cancel_note).pack(side="right")
        ttk.Button(buttons, text="Save Note", command=save_note).pack(
            side="right", padx=(0, 8)
        )

        dialog.bind("<Control-Return>", save_note)
        dialog.bind("<Escape>", cancel_note)
        dialog.protocol("WM_DELETE_WINDOW", cancel_note)

        text.focus_set()
        dialog.wait_window()
        return result["value"]

    def _add_note(self):
        if not self._ensure_saved():
            return
        result = self._note_dialog("Add Note")
        if result:
            self.db.add_note(self.current_id, *result)
            self._refresh_notes()

    def _edit_note(self):
        selected = self.notes_tree.selection()
        if not selected:
            return
        note_id = int(selected[0])
        existing = next((r for r in self.db.get_notes(self.current_id) if int(r["id"]) == note_id), None)
        if not existing:
            return
        result = self._note_dialog("Edit Note", existing)
        if result:
            self.db.update_note(note_id, *result)
            self._refresh_notes()

    def _delete_note(self):
        selected = self.notes_tree.selection()
        if not selected:
            return
        if messagebox.askyesno(APP_NAME, "Delete the selected note?"):
            self.db.delete_note(int(selected[0]))
            self._refresh_notes()

    def _refresh_notes(self):
        for item in self.notes_tree.get_children():
            self.notes_tree.delete(item)
        if self.current_id is None:
            return
        for row in self.db.get_notes(self.current_id):
            one_line = " ".join((row["note_text"] or "").split())
            self.notes_tree.insert("", "end", iid=str(row["id"]), values=(row["note_date"], row["subject"], one_line))

    def _refresh_documents(self):
        for item in self.documents_tree.get_children():
            self.documents_tree.delete(item)
        if self.current_id is None:
            return
        for row in self.db.get_documents(self.current_id):
            self.documents_tree.insert("", "end", iid=str(row["id"]), values=(row["document_name"], row["file_path"]))

    def clear(self):
        self.current_id = None
        self.title_label.configure(text="Add Job Application")
        for var in self.vars.values():
            var.set("")
        self.vars["status"].set("Applied")
        self.vars["applied_at"].set(datetime.now().strftime("%Y-%m-%d"))
        self.vars["follow_up_date"].set((date.today() + timedelta(days=7)).isoformat())
        self.description_text.delete("1.0", "end")
        self.application_materials_text.delete("1.0", "end")
        self._refresh_notes()
        self._refresh_documents()
        self._refresh_questions()

    def load(self, row):
        self.current_id = int(row["id"])
        self.title_label.configure(text=f"Edit Application #{self.current_id}")
        for key, var in self.vars.items():
            var.set(row[key] or "")
        self.description_text.delete("1.0", "end")
        self.description_text.insert("1.0", row["job_description"] or "")
        self.application_materials_text.delete("1.0", "end")
        self.application_materials_text.insert("1.0", row["job_description_file"] or "")
        self._refresh_notes()
        self._refresh_documents()
        self._refresh_questions()


class JobTrackerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("1320x760")
        self.minsize(1040, 650)
        self.db = Database(DATABASE_PATH)
        self._initialize_resume_choices()
        self._install_edit_context_menu()
        self.protocol("WM_DELETE_WINDOW", self._close)

        self.search_var = tk.StringVar()
        self.status_filter_var = tk.StringVar()
        self.platform_filter_var = tk.StringVar()
        self.follow_up_filter_var = tk.StringVar()
        self.status_message = tk.StringVar(value="Ready")
        self.sort_column = "applied_at"
        self.sort_descending = True
        self.main_column_labels = {
            "id": "ID", "company": "Company", "job_title": "Job Title",
            "status": "Status", "applied_at": "Applied", "platform": "Platform",
            "pay_disclosed": "Pay", "resume_used": "Resume",
            "recruiter_name": "Recruiter", "follow_up_date": "Follow-Up",
            "open_question_count": "Open Qs",
        }

        self._build_ui()
        self.refresh_table()

    def _initialize_resume_choices(self):
        """Create the resume-list file and preserve labels from an upgraded database."""
        if RESUMES_FILE.exists() and RESUMES_FILE.read_text(encoding="utf-8").strip():
            return
        existing: list[str] = []
        try:
            existing = [
                (row["resume_used"] or "").strip()
                for row in self.db.all_rows()
                if (row["resume_used"] or "").strip()
            ]
        except sqlite3.Error:
            existing = []
        save_resume_choices(existing)

    def _install_edit_context_menu(self):
        """Provide Cut/Copy/Paste/Delete/Select All on right-click for editable text controls."""
        self._edit_context_widget = None
        self._edit_context_menu = tk.Menu(self, tearoff=False)
        self._edit_context_menu.add_command(label="Cut", command=lambda: self._context_event("<<Cut>>"))
        self._edit_context_menu.add_command(label="Copy", command=lambda: self._context_event("<<Copy>>"))
        self._edit_context_menu.add_command(label="Paste", command=lambda: self._context_event("<<Paste>>"))
        self._edit_context_menu.add_separator()
        self._edit_context_menu.add_command(label="Delete", command=self._context_delete)
        self._edit_context_menu.add_command(label="Select All", command=self._context_select_all)

        for sequence in ("<Button-3>", "<Button-2>", "<Control-Button-1>"):
            self.bind_all(sequence, self._show_edit_context_menu, add="+")

    @staticmethod
    def _is_text_control(widget) -> bool:
        try:
            return widget.winfo_class() in {"Entry", "TEntry", "Text", "TCombobox", "Spinbox", "TSpinbox"}
        except tk.TclError:
            return False

    @staticmethod
    def _is_read_only(widget) -> bool:
        try:
            state = str(widget.cget("state"))
        except (tk.TclError, AttributeError):
            state = "normal"
        return state in {"disabled", "readonly"}

    def _show_edit_context_menu(self, event):
        widget = event.widget
        if not self._is_text_control(widget):
            return
        self._edit_context_widget = widget
        try:
            widget.focus_set()
        except tk.TclError:
            pass

        locked = self._is_read_only(widget)
        for index in (0, 2, 4):  # Cut, Paste, Delete
            self._edit_context_menu.entryconfigure(index, state=("disabled" if locked else "normal"))
        self._edit_context_menu.entryconfigure(1, state="normal")  # Copy
        self._edit_context_menu.entryconfigure(5, state="normal")  # Select All

        try:
            self._edit_context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self._edit_context_menu.grab_release()
        return "break"

    def _context_event(self, virtual_event: str):
        widget = self._edit_context_widget
        if widget is None:
            return
        try:
            widget.event_generate(virtual_event)
        except tk.TclError:
            pass

    def _context_delete(self):
        widget = self._edit_context_widget
        if widget is None or self._is_read_only(widget):
            return
        try:
            if widget.winfo_class() == "Text":
                if widget.tag_ranges("sel"):
                    widget.delete("sel.first", "sel.last")
            elif widget.selection_present():
                widget.delete("sel.first", "sel.last")
        except (tk.TclError, AttributeError):
            pass

    def _context_select_all(self):
        widget = self._edit_context_widget
        if widget is None:
            return
        try:
            if widget.winfo_class() == "Text":
                widget.tag_add("sel", "1.0", "end-1c")
                widget.mark_set("insert", "1.0")
                widget.see("insert")
            else:
                widget.selection_range(0, "end")
                widget.icursor("end")
        except (tk.TclError, AttributeError):
            pass

    def manage_resumes(self):
        """Edit the user-managed list shown in each application's Resume Used dropdown."""
        dialog = tk.Toplevel(self)
        dialog.title("Manage Resumes")
        dialog.geometry("620x430")
        dialog.minsize(500, 340)
        dialog.transient(self)
        dialog.grab_set()
        dialog.columnconfigure(0, weight=1)
        dialog.rowconfigure(2, weight=1)

        ttk.Label(dialog, text="Resume choices", font=("TkDefaultFont", 14, "bold")).grid(
            row=0, column=0, sticky="w", padx=14, pady=(14, 4)
        )
        ttk.Label(
            dialog,
            text=("Enter one resume name or version per line. These labels appear in the "
                  "Resume Used dropdown for applications. Actual resume files can still be "
                  "saved as application documents."),
            wraplength=570,
            justify="left",
        ).grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 8))

        text = tk.Text(dialog, wrap="none", height=12)
        text.grid(row=2, column=0, sticky="nsew", padx=14, pady=(0, 10))
        current = load_resume_choices()[1:]
        if current:
            text.insert("1.0", "\n".join(current))

        buttons = ttk.Frame(dialog)
        buttons.grid(row=3, column=0, sticky="ew", padx=14, pady=(0, 14))
        ttk.Button(buttons, text="Cancel", command=dialog.destroy).pack(side="right")

        def save_and_close():
            labels = text.get("1.0", "end").splitlines()
            try:
                save_resume_choices(labels)
            except OSError as error:
                messagebox.showerror(APP_NAME, f"Unable to save resume choices:\n{error}", parent=dialog)
                return
            dialog.destroy()
            messagebox.showinfo(
                APP_NAME,
                "Resume choices saved. New application windows will use the updated list.",
                parent=self,
            )

        ttk.Button(buttons, text="Save", command=save_and_close).pack(side="right", padx=(0, 8))
        text.focus_set()

    def _build_ui(self):
        toolbar = ttk.Frame(self, padding=(10,10,10,5))
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="Add Application", command=self.show_add_form).pack(side="left", padx=(0,6))
        ttk.Button(toolbar, text="Edit Selected", command=self.edit_selected).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Open Posting", command=self.open_selected_posting).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Delete Selected", command=self.delete_selected).pack(side="left", padx=6)
        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=10)
        ttk.Button(toolbar, text="Import CSV", command=self.import_csv).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Export CSV", command=self.export_csv).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Back Up Data", command=self.backup_data).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Open Data Folder", command=self.open_data_folder).pack(side="left", padx=6)
        ttk.Button(toolbar, text="Manage Resumes", command=self.manage_resumes).pack(side="left", padx=6)

        applications_tab = ttk.Frame(self)
        applications_tab.pack(fill="both", expand=True, padx=8, pady=(0,8))

        filters = ttk.Frame(applications_tab, padding=(10,5))
        filters.pack(fill="x")
        ttk.Label(filters, text="Search").pack(side="left")
        entry = ttk.Entry(filters, textvariable=self.search_var, width=30)
        entry.pack(side="left", padx=(6,12))
        entry.bind("<KeyRelease>", lambda e: self.refresh_table())
        ttk.Label(filters, text="Status").pack(side="left")
        status = ttk.Combobox(filters, textvariable=self.status_filter_var, values=[""] + STATUSES, state="readonly", width=22)
        status.pack(side="left", padx=(6,12))
        status.bind("<<ComboboxSelected>>", lambda e: self.refresh_table())
        ttk.Label(filters, text="Platform").pack(side="left")
        platform = ttk.Combobox(filters, textvariable=self.platform_filter_var, values=PLATFORMS, state="readonly", width=14)
        platform.pack(side="left", padx=(6,12))
        platform.bind("<<ComboboxSelected>>", lambda e: self.refresh_table())
        ttk.Label(filters, text="Follow-Up").pack(side="left")
        follow_up = ttk.Combobox(
            filters, textvariable=self.follow_up_filter_var,
            values=FOLLOW_UP_FILTERS, state="readonly", width=12
        )
        follow_up.pack(side="left", padx=(6,12))
        follow_up.bind("<<ComboboxSelected>>", lambda e: self.refresh_table())
        ttk.Button(filters, text="Clear Filters", command=self.clear_filters).pack(side="left")
        ttk.Button(filters, text="Set Missing +7", command=self.backfill_followups).pack(side="left", padx=(8,0))

        summary = ttk.Frame(applications_tab, padding=(10,6))
        summary.pack(fill="x")
        self.summary_labels = {}
        for key, title in [
            ("total", "Total"), ("applied", "Applied"),
            ("active", "Active Process"), ("offers", "Offers"),
            ("due_today", "Due Today"), ("overdue", "Overdue"),
            ("open_questions", "Open Questions")
        ]:
            label = ttk.Label(summary, text=f"{title}: 0", font=("TkDefaultFont", 10, "bold"))
            label.pack(side="left", padx=(0,18))
            self.summary_labels[key] = label

        body = ttk.Frame(applications_tab, padding=(10,5,10,10))
        body.pack(fill="both", expand=True)
        columns = (
            "id", "company", "job_title", "status", "applied_at", "platform",
            "pay_disclosed", "resume_used", "recruiter_name", "follow_up_date",
            "open_question_count"
        )
        self.tree = ttk.Treeview(body, columns=columns, show="headings", selectmode="browse")
        widths = {
            "id":50, "company":140, "job_title":175, "status":125,
            "applied_at":95, "platform":90, "pay_disclosed":90,
            "resume_used":150, "recruiter_name":120, "follow_up_date":95,
            "open_question_count":70
        }
        for column in columns:
            self.tree.column(column, width=widths[column], minwidth=55, stretch=False)
        self._update_sort_headings()

        self.tree.tag_configure("just_applied", background="#ffffff", foreground="#111111")
        self.tree.tag_configure("rejected", background="#111111", foreground="#ffffff")
        self.tree.tag_configure("interview", background="#b9d8ff", foreground="#111111")
        self.tree.tag_configure("accepted", background="#b9efc5", foreground="#111111")
        y = ttk.Scrollbar(body, orient="vertical", command=self.tree.yview)
        x = ttk.Scrollbar(body, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        y.grid(row=0, column=1, sticky="ns")
        x.grid(row=1, column=0, sticky="ew")
        body.columnconfigure(0, weight=1)
        body.rowconfigure(0, weight=1)
        self.tree.bind("<Double-1>", lambda e: self.edit_selected())
        self.tree.bind("<Return>", lambda e: self.edit_selected())


        ttk.Label(self, textvariable=self.status_message, anchor="w", relief="sunken", padding=(8,4)).pack(fill="x", side="bottom")
        self.form_window = None

    def refresh_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        rows = self.db.search(
            self.search_var.get(), self.status_filter_var.get(),
            self.platform_filter_var.get(), self.follow_up_filter_var.get(),
            self.sort_column, self.sort_descending
        )
        for row in rows:
            status = row["status"] or ""
            interview_date = (row["interview_date"] or "").strip()
            if status == "Rejected":
                tag = "rejected"
            elif status in {"Offer", "Accepted"}:
                tag = "accepted"
            elif interview_date or status in {"Recruiter Contacted", "Phone Screen", "Interview Scheduled",
                                              "Interview Completed", "Assessment"}:
                # An entered interview date/time is direct evidence that the application
                # has entered the interview phase, even if the Status field was not updated.
                tag = "interview"
            else:
                tag = "just_applied"
            applied_display = (row["applied_at"] or "").split()[0]
            self.tree.insert("", "end", iid=str(row["id"]), tags=(tag,), values=(
                row["id"], row["company"], row["job_title"], status,
                applied_display, row["platform"], row["pay_disclosed"],
                row["resume_used"], row["recruiter_name"], row["follow_up_date"],
                row["open_question_count"]
            ))
        counts = self.db.counts()
        titles = {
            "total": "Total", "applied": "Applied", "active": "Active Process",
            "offers": "Offers", "due_today": "Due Today", "overdue": "Overdue",
            "open_questions": "Open Questions"
        }
        for key, label in self.summary_labels.items():
            label.configure(text=f"{titles[key]}: {counts[key]}")
        self.status_message.set(f"Showing {len(rows)} record(s) | Database: {DATABASE_PATH}")
        self._update_sort_headings()

    def _update_sort_headings(self):
        if not hasattr(self, "tree"):
            return
        for column, label in self.main_column_labels.items():
            indicator = ""
            if column == self.sort_column:
                indicator = " \u25bc" if self.sort_descending else " \u25b2"
            self.tree.heading(
                column, text=label + indicator,
                command=lambda col=column: self.sort_by(col)
            )

    def sort_by(self, column):
        if column not in self.main_column_labels:
            return
        if self.sort_column == column:
            self.sort_descending = not self.sort_descending
        else:
            self.sort_column = column
            self.sort_descending = column in {
                "id", "applied_at", "follow_up_date", "open_question_count"
            }
        self.refresh_table()

    def backfill_followups(self):
        if not messagebox.askyesno(
            APP_NAME,
            "Set every active application with no follow-up date to seven days after its applied date?"
        ):
            return
        updated = self.db.set_missing_followups(7)
        self.refresh_table()
        messagebox.showinfo(APP_NAME, f"Set {updated} missing follow-up date(s).")

    def clear_filters(self):
        self.search_var.set("")
        self.status_filter_var.set("")
        self.platform_filter_var.set("")
        self.follow_up_filter_var.set("")
        self.refresh_table()

    def selected_id(self):
        selected = self.tree.selection()
        return int(selected[0]) if selected else None

    def show_add_form(self):
        self._open_form(None)

    def edit_selected(self):
        app_id = self.selected_id()
        if app_id is None:
            messagebox.showinfo(APP_NAME, "Select an application to edit.")
            return
        self._open_form(app_id)

    def _open_form(self, app_id):
        if self.form_window and self.form_window.winfo_exists():
            self.form_window.lift()
            return
        self.form_window = tk.Toplevel(self)
        self.form_window.geometry("980x740")
        self.form_window.minsize(820, 620)
        self.form_window.transient(self)

        form_holder = {"form": None}

        def close_without_prompt():
            if self.form_window and self.form_window.winfo_exists():
                self.form_window.destroy()
            self.form_window = None

        form = ApplicationForm(
            self.form_window,
            self.db,
            self.refresh_table,
            close_without_prompt,
        )
        form_holder["form"] = form
        form.pack(fill="both", expand=True)

        if app_id is None:
            form.clear()
        else:
            row = self.db.get(app_id)
            if row:
                form.load(row)

        def close_with_prompt():
            current_form = form_holder["form"]
            if current_form is None:
                close_without_prompt()
                return

            company = current_form.vars["company"].get().strip()
            title = current_form.vars["job_title"].get().strip()

            if not company and not title:
                close_without_prompt()
                return

            choice = messagebox.askyesnocancel(
                APP_NAME,
                "Save this application before closing?\n\n"
                "Yes: save and close\n"
                "No: close without saving\n"
                "Cancel: return to the form",
                parent=self.form_window,
            )
            if choice is None:
                return
            if choice:
                if current_form.save_record(close_after=False, show_message=False):
                    close_without_prompt()
            else:
                close_without_prompt()

        self.form_window.protocol("WM_DELETE_WINDOW", close_with_prompt)

    def open_selected_posting(self):
        app_id = self.selected_id()
        if app_id is None:
            messagebox.showinfo(APP_NAME, "Select an application first.")
            return
        self._open_posting_for_id(app_id)

    def _open_posting_for_id(self, app_id: int):
        row = self.db.get(app_id)
        url = normalize_url(row["job_url"] or "") if row else ""
        if not url:
            messagebox.showinfo(APP_NAME, "The selected application has no job posting URL.")
            return
        try:
            opened = webbrowser.open(url, new=2)
        except webbrowser.Error as error:
            messagebox.showerror(APP_NAME, f"Unable to open the job posting:\n{error}")
            return
        if not opened:
            messagebox.showwarning(
                APP_NAME,
                f"The browser did not confirm that it opened:\n{url}",
            )

    def backup_data(self):
        default_name = f"AOAL_data_backup_{datetime.now():%Y-%m-%d_%H%M%S}.zip"
        destination = filedialog.asksaveasfilename(
            title="Back up AOAL data",
            defaultextension=".zip",
            initialfile=default_name,
            filetypes=[("ZIP archives", "*.zip")],
        )
        if not destination:
            return

        try:
            with tempfile.TemporaryDirectory(prefix="aoal_backup_") as temp_dir:
                temp_root = Path(temp_dir) / "job_tracker_data"
                temp_root.mkdir(parents=True, exist_ok=True)
                self.db.backup_to(temp_root / DATABASE_PATH.name)

                if ATTACHMENTS_DIR.exists():
                    shutil.copytree(
                        ATTACHMENTS_DIR,
                        temp_root / "attachments",
                        dirs_exist_ok=True,
                    )

                if RESUMES_FILE.exists():
                    shutil.copy2(RESUMES_FILE, temp_root / RESUMES_FILE.name)

                manifest = (
                    "AOAL data backup\n"
                    f"Created: {datetime.now():%Y-%m-%d %H:%M:%S}\n"
                    f"Application version: {APP_VERSION}\n"
                    "Contains the SQLite database, resume-choice list, and saved attachments.\n"
                )
                (Path(temp_dir) / "BACKUP_INFO.txt").write_text(
                    manifest,
                    encoding="utf-8",
                )

                with zipfile.ZipFile(
                    destination,
                    "w",
                    compression=zipfile.ZIP_DEFLATED,
                ) as archive:
                    for file_path in sorted(Path(temp_dir).rglob("*")):
                        if file_path.is_file():
                            archive.write(file_path, file_path.relative_to(temp_dir))
        except (OSError, sqlite3.Error, zipfile.BadZipFile) as error:
            messagebox.showerror(APP_NAME, f"Unable to create the backup:\n{error}")
            return

        messagebox.showinfo(
            APP_NAME,
            f"AOAL data backup created successfully:\n{destination}",
        )

    def delete_selected(self):
        app_id = self.selected_id()
        if app_id is None:
            messagebox.showinfo(APP_NAME, "Select an application to delete.")
            return
        if messagebox.askyesno(APP_NAME, "Delete the selected application and its saved notes/documents?"):
            self.db.delete(app_id)
            self.refresh_table()

    def import_csv(self):
        source = filedialog.askopenfilename(
            title="Import job applications from CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if not source:
            return

        valid_fields = {
            "company", "job_title", "job_description", "pay_disclosed", "platform",
            "job_url", "resume_used", "document_used", "applied_at", "status",
            "recruiter_name", "recruiter_email", "recruiter_phone", "contact_method",
            "location", "work_arrangement", "employment_type", "application_id",
            "follow_up_date", "interview_date", "notes", "job_description_file",
            "resume_file", "cover_letter_file", "created_at", "updated_at"
        }

        try:
            with open(source, "r", newline="", encoding="utf-8-sig") as file:
                reader = csv.DictReader(file)
                if not reader.fieldnames:
                    messagebox.showerror(APP_NAME, "The CSV file does not contain column headings.")
                    return

                imported = 0
                skipped = 0
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                for raw_row in reader:
                    normalized = {
                        (key or "").strip(): (value or "").strip()
                        for key, value in raw_row.items()
                    }

                    company = normalized.get("company", "")
                    job_title = normalized.get("job_title", "")

                    if not company or not job_title:
                        skipped += 1
                        continue

                    record = {}
                    for field in valid_fields:
                        if field in {"created_at", "updated_at"}:
                            continue
                        record[field] = normalized.get(field, "")

                    if not record.get("status"):
                        record["status"] = "Applied"
                    if not record.get("follow_up_date") and record["status"] not in TERMINAL_STATUSES:
                        record["follow_up_date"] = default_follow_up_date(record.get("applied_at", ""))

                    record["created_at"] = normalized.get("created_at") or now
                    record["updated_at"] = normalized.get("updated_at") or now

                    self.db.insert(record)
                    imported += 1

            self.refresh_table()

            message = f"Imported {imported} application(s)."
            if skipped:
                message += (
                    f"\n\nSkipped {skipped} row(s) because Company or Job Title was missing."
                )
            messagebox.showinfo(APP_NAME, message)

        except UnicodeDecodeError:
            messagebox.showerror(
                APP_NAME,
                "The CSV could not be read as UTF-8. Save it as CSV UTF-8 and try again."
            )
        except csv.Error as error:
            messagebox.showerror(APP_NAME, f"Invalid CSV file:\n{error}")
        except OSError as error:
            messagebox.showerror(APP_NAME, f"Unable to import CSV:\n{error}")
        except sqlite3.Error as error:
            messagebox.showerror(APP_NAME, f"Database import failed:\n{error}")

    def export_csv(self):
        rows = self.db.all_rows()
        if not rows:
            messagebox.showinfo(APP_NAME, "There are no records to export.")
            return
        dest = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"job_applications_{datetime.now():%Y-%m-%d}.csv", filetypes=[("CSV files","*.csv")])
        if not dest:
            return
        fields = list(rows[0].keys()) + ["clarification_questions", "clarification_answers"]
        with open(dest, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for row in rows:
                exported = dict(row)
                questions, answers = self.db.question_export_text(int(row["id"]))
                exported["clarification_questions"] = questions
                exported["clarification_answers"] = answers
                writer.writerow(exported)
        messagebox.showinfo(APP_NAME, f"Exported {len(rows)} record(s).")

    def open_data_folder(self):
        if sys.platform.startswith("win"):
            os.startfile(DATA_DIR)
        elif sys.platform == "darwin":
            subprocess.run(["open", str(DATA_DIR)], check=False)
        else:
            subprocess.run(["xdg-open", str(DATA_DIR)], check=False)

    def _close(self):
        self.db.close()
        self.destroy()


if __name__ == "__main__":
    JobTrackerApp().mainloop()
